/*
    In this file, we'll be continuing our story
    with Jon being allowed to flee his fight with Jamie.
*/